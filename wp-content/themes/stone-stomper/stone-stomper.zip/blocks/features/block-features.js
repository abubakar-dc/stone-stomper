/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/block-assets/components/ContainerBlock.jsx":
/*!********************************************************!*\
  !*** ./src/block-assets/components/ContainerBlock.jsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ContainerBlockContent: () => (/* binding */ ContainerBlockContent),
/* harmony export */   customAttributes: () => (/* binding */ customAttributes),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _DesignOption_jsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./DesignOption.jsx */ "./src/block-assets/components/DesignOption.jsx");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);





const ContainerBlock = ({
  children,
  props,
  customClass = '',
  hideWrapper = false
}) => {
  const {
    attributes,
    setAttributes
  } = props;
  const myCustomWidthClass = attributes.bgWidth ? 'content-width-border ctn editor-' + attributes.bgWidth : '';
  const myCustomBorderClass = attributes.designBorder ? 'editor-' + attributes.designBorder : '';
  const myCustomDesignClass = attributes.bgDesignType ? 'editor-' + attributes.bgDesignType : '';
  const myCustomShapeClass = attributes.bgShape ? 'editor-' + attributes.bgShape : '';
  const myCustomBoxClass = attributes.hasBoxedBackground ? '' : 'without-boxed';
  const myCustomOverlapClass = attributes.hasOverlap ? 'editor-block-overlap' : '';
  const ContainerClasses = [myCustomDesignClass, myCustomWidthClass, myCustomBorderClass, myCustomShapeClass, myCustomBoxClass, myCustomOverlapClass, customClass].join(' ');
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_1__.InspectorControls, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.Panel, {
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.PanelBody, {
          title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Container'),
          initialOpen: true,
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
            className: "theme-containers container-width",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.PanelRow, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("h2", {
                children: "Content Width"
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.PanelRow, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.SelectControl, {
                value: attributes.bgWidth,
                className: "dc-sidebar-select",
                options: [{
                  label: '1390px (Default)',
                  value: 'ctn'
                }, {
                  label: '1920px',
                  value: 'ctn-1920'
                }, {
                  label: '1790px',
                  value: 'ctn-1790'
                }, {
                  label: '1300px',
                  value: 'ctn-1300'
                }, {
                  label: '1160px',
                  value: 'ctn-1160'
                }, {
                  label: '960px',
                  value: 'ctn-960'
                }, {
                  label: '690px',
                  value: 'ctn-690'
                }, {
                  label: 'Full Width',
                  value: 'ctn-full-width'
                }],
                onChange: value => setAttributes({
                  bgWidth: value
                })
              })
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("hr", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
            className: "theme-containers container-design",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.PanelRow, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("h2", {
                children: "Background Color"
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.PanelRow, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_DesignOption_jsx__WEBPACK_IMPORTED_MODULE_3__["default"], {
                props: props,
                value: attributes.bgDesignType,
                DesignKey: "bgDesignType",
                help: "",
                options: [{
                  label: 'Light Pink ',
                  value: 'ctn-light-pink',
                  display: '#ffffff'
                }, {
                  label: 'Brown',
                  value: 'ctn-brown',
                  display: '#C3B8A6'
                }]
              })
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("hr", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
            className: "theme-containers container-design",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.PanelRow, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("h2", {
                children: "Container Margin"
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.PanelRow, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.SelectControl, {
                value: attributes.marginTop,
                label: "Top",
                className: "dc-sidebar-select",
                options: [{
                  label: '96px (Default)',
                  value: ''
                }, {
                  label: '2px',
                  value: 'st-s2'
                }, {
                  label: '4px',
                  value: 'st-s4'
                }, {
                  label: '6px',
                  value: 'st-s6'
                }, {
                  label: '8px',
                  value: 'st-s8'
                }, {
                  label: '12px',
                  value: 'st-s12'
                }, {
                  label: '16px',
                  value: 'st-s16'
                }, {
                  label: '20px',
                  value: 'st-s20'
                }, {
                  label: '24px',
                  value: 'st-s24'
                }, {
                  label: '30px',
                  value: 'st-s30'
                }, {
                  label: '36px',
                  value: 'st-s36'
                }, {
                  label: '48px',
                  value: 'st-s48'
                }, {
                  label: '56px',
                  value: 'st-s56'
                }, {
                  label: '60px',
                  value: 'st-s60'
                }, {
                  label: '72px',
                  value: 'st-s72'
                }, {
                  label: '80px',
                  value: 'st-s80'
                }, {
                  label: '120px',
                  value: 'st-s120'
                }, {
                  label: '128px',
                  value: 'st-s128'
                }, {
                  label: '156px',
                  value: 'st-s156'
                }, {
                  label: '200px',
                  value: 'st-s200'
                }, {
                  label: '240px',
                  value: 'st-s240'
                }],
                onChange: value => setAttributes({
                  marginTop: value
                })
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.PanelRow, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.SelectControl, {
                value: attributes.marginBottom,
                label: "Bottom",
                className: "dc-sidebar-select",
                options: [{
                  label: '96px (Default)',
                  value: ''
                }, {
                  label: '2px',
                  value: 'st-s2'
                }, {
                  label: '4px',
                  value: 'st-s4'
                }, {
                  label: '6px',
                  value: 'st-s6'
                }, {
                  label: '8px',
                  value: 'st-s8'
                }, {
                  label: '12px',
                  value: 'st-s12'
                }, {
                  label: '16px',
                  value: 'st-s16'
                }, {
                  label: '20px',
                  value: 'st-s20'
                }, {
                  label: '24px',
                  value: 'st-s24'
                }, {
                  label: '30px',
                  value: 'st-s30'
                }, {
                  label: '36px',
                  value: 'st-s36'
                }, {
                  label: '48px',
                  value: 'st-s48'
                }, {
                  label: '56px',
                  value: 'st-s56'
                }, {
                  label: '60px',
                  value: 'st-s60'
                }, {
                  label: '72px',
                  value: 'st-s72'
                }, {
                  label: '80px',
                  value: 'st-s80'
                }, {
                  label: '120px',
                  value: 'st-s120'
                }, {
                  label: '128px',
                  value: 'st-s128'
                }, {
                  label: '156px',
                  value: 'st-s156'
                }, {
                  label: '200px',
                  value: 'st-s200'
                }, {
                  label: '240px',
                  value: 'st-s240'
                }],
                onChange: value => setAttributes({
                  marginBottom: value
                })
              })
            })]
          })]
        })
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("div", {
      className: 'dc-spacer ' + attributes.marginTop
    }), hideWrapper ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("section", {
      className: ContainerClasses,
      children: children
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("section", {
      className: ContainerClasses,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("div", {
        className: "wrapper",
        children: children
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("div", {
      className: 'dc-spacer ' + attributes.marginBottom
    })]
  });
};
const ContainerBlockContent = ({
  children,
  props,
  customClass = '',
  hideWrapper = false
}) => {
  const {
    attributes
  } = props;
  const myCustomWidthClass = attributes.bgWidth ? attributes.bgWidth : 'ctn';
  const myCustomBorderClass = attributes.designBorder ? attributes.designBorder : ' ';
  const myCustomDesignClass = attributes.bgDesignType ? attributes.bgDesignType : '';
  const myCustomShapeClass = attributes.bgShape ? attributes.bgShape : '';
  const myCustomBoxClass = attributes.hasBoxedBackground ? '' : 'without-boxed';
  const myCustomOverlapClass = attributes.hasOverlap ? 'ctn-overlap' : '';
  const ContainerClasses = [myCustomDesignClass, myCustomWidthClass, myCustomBorderClass, myCustomShapeClass, myCustomBoxClass, myCustomOverlapClass, customClass].join(' ');
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
    children: [attributes.marginTop ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("div", {
      className: 'dc-spacer ' + attributes.marginTop
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {}), hideWrapper ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("section", {
      className: ContainerClasses,
      children: children
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("section", {
      className: 'ctn ' + ContainerClasses,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("div", {
        className: "wrapper",
        children: children
      })
    }), attributes.marginBottom ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("div", {
      className: 'dc-spacer ' + attributes.marginBottom
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {})]
  });
};
const customAttributes = {
  bgDesignType: {
    type: 'string',
    default: ''
  },
  bgWidth: {
    type: 'string',
    default: 'ctn'
  },
  designBorder: {
    type: 'string',
    default: ''
  },
  marginTop: {
    type: 'string',
    default: ''
  },
  marginBottom: {
    type: 'string',
    default: ''
  },
  hasBoxedBackground: {
    type: 'boolean',
    default: false
  },
  hasOverlap: {
    type: 'boolean',
    default: false
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContainerBlock);


/***/ }),

/***/ "./src/block-assets/components/DesignOption.jsx":
/*!******************************************************!*\
  !*** ./src/block-assets/components/DesignOption.jsx ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ DesignOption)
/* harmony export */ });
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _UseImage_jsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UseImage.jsx */ "./src/block-assets/components/UseImage.jsx");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);



function DesignOption({
  props,
  value,
  DesignKey,
  options,
  help
}) {
  const {
    setAttributes
  } = props;
  const checkBoxEffect = event => {
    const button = event.target.parentNode;
    const dataValue = button.getAttribute('data-value');
    // Remove the "selected" class from all other buttons
    const buttons = document.querySelectorAll('.design-option-btn');
    buttons.forEach(btn => {
      btn = btn.parentNode;
      if (btn !== button) {
        btn.classList.remove('selected');
      }
    });

    // Toggle the "selected" class for the clicked button
    button.classList.toggle('selected');
    if (button.classList.contains('selected')) {
      setAttributes({
        [DesignKey]: dataValue
      });
    } else {
      setAttributes({
        [DesignKey]: ''
      });
    }
  };
  const getContrastingTextColor = bgColor => {
    // Convert the background color to RGB values
    let rgb = [];
    if (/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(bgColor)) {
      // Valid hex color value, convert to RGB
      rgb = bgColor.match(/\w{2}/g).map(hex => parseInt(hex, 16));
    } else if (/^rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\)$/.test(bgColor)) {
      // Valid RGB color value
      rgb = bgColor.match(/\d+/g).map(Number);
    }
    const brightness = (rgb[0] * 299 + rgb[1] * 587 + rgb[2] * 114) / 1000; // Calculate brightness
    // Set the text color based on brightness threshold (you can adjust the threshold as needed)
    return brightness > 128 ? '#000000' : '#FFFFFF';
  };
  const Buttons = options.map((element, index) => {
    let selected = 'design-option-item';
    if (value === element.value) {
      selected = 'design-option-item selected';
    }
    let myStyle = {};
    if (element.display.startsWith('#')) {
      myStyle = {
        position: 'relative',
        '--bg_container_color': element.display,
        '--bg_container_circle_color': getContrastingTextColor(element.display),
        fontSize: '20px'
      };
    } else {
      const {
        image
      } = (0,_UseImage_jsx__WEBPACK_IMPORTED_MODULE_1__["default"])(element.display);
      if (image) {
        myStyle = {
          backgroundImage: 'url(' + image + ')'
        };
      }
    }
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_wordpress_components__WEBPACK_IMPORTED_MODULE_0__.Tooltip, {
        text: element.label,
        position: 'bottom',
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
          className: selected,
          style: myStyle,
          "data-value": element.value,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("button", {
            onClick: event => {
              checkBoxEffect(event);
            },
            className: "design-option-btn",
            children: [element.display.startsWith('#') ? element.label : '', /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("svg", {
              xmlns: "http://www.w3.org/2000/svg",
              viewBox: "0 0 24 24",
              width: "24",
              height: "24",
              fill: "#fff",
              "aria-hidden": "true",
              focusable: "false",
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("path", {
                d: "M16.7 7.1l-6.3 8.5-3.3-2.5-.9 1.2 4.5 3.4L17.9 8z"
              })
            })]
          }, index)
        })
      })
    });
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
      className: "dc-sidebar-help-text",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("p", {
        className: "components-base-control__help",
        children: help
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
      className: "design-option",
      children: Buttons
    })]
  });
}

/***/ }),

/***/ "./src/block-assets/components/UseImage.jsx":
/*!**************************************************!*\
  !*** ./src/block-assets/components/UseImage.jsx ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const UseImage = fileName => {
  const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
  const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const [image, setImage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const fetchImage = async () => {
      try {
        const response = await Object(function webpackMissingModule() { var e = new Error("Cannot find module 'undefined'"); e.code = 'MODULE_NOT_FOUND'; throw e; }()); // change relative path to suit your needs
        setImage(response);
      } catch (err) {
        setError(err);
      } finally {
        setLoading(false);
      }
    };
    fetchImage();
  }, [fileName]);
  return {
    loading,
    error,
    image
  };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UseImage);

/***/ }),

/***/ "./src/block-assets/icons/Icons.jsx":
/*!******************************************!*\
  !*** ./src/block-assets/icons/Icons.jsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const icons = {};
icons.faq = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", {
  id: "fi_4291848",
  enableBackground: "new 0 0 511.999 511.999",
  height: "512",
  viewBox: "0 0 511.999 511.999",
  width: "512",
  xmlns: "http://www.w3.org/2000/svg",
  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "m466.999 70.499h-421.999c-24.813 0-45 20.187-45 45v241.006c0 24.814 20.187 45 45 45h173.5l25.5 33.999c6.002 8.003 18.011 7.986 24 0l25.5-33.999h173.499c24.814 0 45-20.186 45-45v-241.006c0-24.813-20.187-45-45-45zm15 286.006c0 8.271-6.729 15-15 15h-180.999c-4.722 0-9.167 2.223-12 6l-18 23.999-18-23.999c-2.833-3.777-7.278-6-12-6h-181c-8.271 0-15-6.729-15-15v-241.006c0-8.271 6.729-15 15-15h421.999c8.271 0 15 6.729 15 15z"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "m234.122 175.309c-2.491-6.621-8.918-11.305-16.423-11.305-7.165 0-13.558 4.284-16.275 10.926-.098.237 1.887-4.967-42.938 112.729-3.756 9.862 3.585 20.343 14.015 20.343 6.044 0 11.741-3.681 14.02-9.664l6.982-18.331h48.064l6.902 18.287c2.925 7.749 11.577 11.665 19.33 8.738 7.75-2.925 11.663-11.58 8.738-19.33zm-29.194 74.697 12.717-33.392 12.602 33.392z"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "m136.43 194.839c8.284 0 15-6.716 15-15s-6.716-15-15-15h-45.864c-8.284 0-15 6.716-15 15v113.158c0 8.284 6.716 15 15 15 8.283 0 15-6.716 15-15v-42.65h27.221c8.284 0 15-6.716 15-15s-6.716-15-15-15h-27.221v-25.508z"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "m424.723 274.61c7.126-11.166 11.275-24.408 11.275-38.608 0-39.699-32.299-71.997-71.997-71.997-39.7 0-71.996 32.298-71.996 71.997s32.296 71.996 71.996 71.996c14.666 0 28.315-4.418 39.706-11.978l7.124 7.125c5.859 5.858 15.355 5.858 21.213 0 5.858-5.857 5.858-15.355 0-21.213zm-102.718-38.609c0-23.157 18.84-41.997 41.996-41.997 30.039 0 50.476 30.854 38.614 58.498l-7.039-7.039c-5.857-5.857-15.355-5.857-21.213 0s-5.858 15.356 0 21.213l7.378 7.378c-27.634 12.934-59.736-7.284-59.736-38.053z"
    })]
  })
});
icons.container = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", {
  width: "64",
  height: "64",
  viewBox: "0 0 64 64",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M64 15H0V47H64V15ZM4 43H60V19H4V43Z",
    fill: "black"
  })
});
icons.socialFeeds = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "64",
  viewBox: "0 0 64 64",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M4.66667 61.3333H11.3333C13.9067 61.3333 16 59.24 16 56.6667V26C16 23.4267 13.9067 21.3333 11.3333 21.3333H4.66667C2.09333 21.3333 0 23.4267 0 26V56.6667C0 59.24 2.09333 61.3333 4.66667 61.3333Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M34.0827 2C31.416 2 30.0827 3.33333 30.0827 10C30.0827 16.336 23.9467 21.4347 20 24.0613V57.096C24.2693 59.072 32.816 62 46.0827 62H50.3493C55.5493 62 59.976 58.2667 60.856 53.1467L63.8427 35.8133C64.9627 29.28 59.9493 23.3333 53.336 23.3333H40.7493C40.7493 23.3333 42.7493 19.3333 42.7493 12.6667C42.7493 4.66667 36.7493 2 34.0827 2Z",
    fill: "#6B5447"
  })]
});
icons.featuredPost = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "28",
  viewBox: "0 0 64 28",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    clipPath: "url(#clip0_1329_27)",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M60 4H40V24H60V4ZM36 0V28H64V0H36Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46.0714 12L40 20.2143V24H60V20.5714L56.0714 15.9286L52.8571 19.5L46.0714 12Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M58 9.5C58 10.8807 56.8807 12 55.5 12C54.1193 12 53 10.8807 53 9.5C53 8.11929 54.1193 7 55.5 7C56.8807 7 58 8.11929 58 9.5Z",
      fill: "#6B5447"
    })]
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 12L28 16L-1.63189e-07 16L0 12L28 12Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 12L28 16L-1.63189e-07 16L0 12L28 12Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 12L28 16L-1.63189e-07 16L0 12L28 12Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 4L28 8L-1.63189e-07 8L0 4L28 4Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 4L28 8L-1.63189e-07 8L0 4L28 4Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 4L28 8L-1.63189e-07 8L0 4L28 4Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M14 20L14 24L-1.63189e-07 24L0 20L14 20Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M14 20L14 24L-1.63189e-07 24L0 20L14 20Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M14 20L14 24L-1.63189e-07 24L0 20L14 20Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("defs", {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("clipPath", {
      id: "clip0_1329_27",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
        width: "28",
        height: "28",
        fill: "white",
        transform: "translate(36)"
      })
    })
  })]
});
icons.heroHome = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "70px",
  height: "70px",
  viewBox: "0 0 16 16",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    id: "SVGRepo_bgCarrier",
    strokeWidth: "0"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    id: "SVGRepo_tracerCarrier",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    id: "SVGRepo_iconCarrier",
    children: [" ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M1 6V15H6V11C6 9.89543 6.89543 9 8 9C9.10457 9 10 9.89543 10 11V15H15V6L8 0L1 6Z",
      fill: "#000000"
    }), " "]
  })]
});
icons.perksTeaser = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "64",
  viewBox: "0 0 64 64",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    clipPath: "url(#clip0_1415_47)",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
      clipPath: "url(#clip1_1415_47)",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M18.8571 9.14286H3.14286V24.8571H18.8571V9.14286ZM0 6V28H22V6H0Z",
        fill: "#6B5447"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
        d: "M7.91323 15.4286L3.14282 21.8827V24.8572H18.8571V22.1633L15.7704 18.5153L13.2449 21.3214L7.91323 15.4286Z",
        fill: "#6B5447"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
        d: "M17.2857 13.4643C17.2857 14.5491 16.4063 15.4286 15.3215 15.4286C14.2366 15.4286 13.3572 14.5491 13.3572 13.4643C13.3572 12.3794 14.2366 11.5 15.3215 11.5C16.4063 11.5 17.2857 12.3794 17.2857 13.4643Z",
        fill: "#6B5447"
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M22 46.8571L22 50L3.48617e-07 50L4.76837e-07 46.8571L22 46.8571Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M22 46.8571L22 50L3.48617e-07 50L4.76837e-07 46.8571L22 46.8571Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M22 46.8571L22 50L3.48617e-07 50L4.76837e-07 46.8571L22 46.8571Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M22 40.5714L22 43.7143L3.48617e-07 43.7143L4.76837e-07 40.5714L22 40.5714Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M22 40.5714L22 43.7143L3.48617e-07 43.7143L4.76837e-07 40.5714L22 40.5714Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M22 40.5714L22 43.7143L3.48617e-07 43.7143L4.76837e-07 40.5714L22 40.5714Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M22 34.2857L22 37.4286L3.48617e-07 37.4286L4.76837e-07 34.2857L22 34.2857Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M22 34.2857L22 37.4286L3.48617e-07 37.4286L4.76837e-07 34.2857L22 34.2857Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M22 34.2857L22 37.4286L3.48617e-07 37.4286L4.76837e-07 34.2857L22 34.2857Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M11 53.1429L11 56.2857L1.10198e-07 56.2857L2.38419e-07 53.1429L11 53.1429Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M11 53.1429L11 56.2857L1.10198e-07 56.2857L2.38419e-07 53.1429L11 53.1429Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M11 53.1429L11 56.2857L1.10198e-07 56.2857L2.38419e-07 53.1429L11 53.1429Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
      clipPath: "url(#clip2_1415_47)",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M42.8571 9.14286H27.1429V24.8571H42.8571V9.14286ZM24 6V28H46V6H24Z",
        fill: "#6B5447"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
        d: "M31.9132 15.4286L27.1428 21.8827V24.8572H42.8571V22.1633L39.7704 18.5153L37.2449 21.3214L31.9132 15.4286Z",
        fill: "#6B5447"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
        d: "M41.2857 13.4643C41.2857 14.5491 40.4063 15.4286 39.3215 15.4286C38.2366 15.4286 37.3572 14.5491 37.3572 13.4643C37.3572 12.3794 38.2366 11.5 39.3215 11.5C40.4063 11.5 41.2857 12.3794 41.2857 13.4643Z",
        fill: "#6B5447"
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46 46.8571L46 50L24 50L24 46.8571L46 46.8571Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46 46.8571L46 50L24 50L24 46.8571L46 46.8571Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46 46.8571L46 50L24 50L24 46.8571L46 46.8571Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46 40.5714L46 43.7143L24 43.7143L24 40.5714L46 40.5714Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46 40.5714L46 43.7143L24 43.7143L24 40.5714L46 40.5714Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46 40.5714L46 43.7143L24 43.7143L24 40.5714L46 40.5714Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46 34.2857L46 37.4286L24 37.4286L24 34.2857L46 34.2857Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46 34.2857L46 37.4286L24 37.4286L24 34.2857L46 34.2857Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46 34.2857L46 37.4286L24 37.4286L24 34.2857L46 34.2857Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M35 53.1429L35 56.2857L24 56.2857L24 53.1429L35 53.1429Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M35 53.1429L35 56.2857L24 56.2857L24 53.1429L35 53.1429Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M35 53.1429L35 56.2857L24 56.2857L24 53.1429L35 53.1429Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
      clipPath: "url(#clip3_1415_47)",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        d: "M66.8571 9.14286H51.1429V24.8571H66.8571V9.14286ZM48 6V28H70V6H48Z",
        fill: "#6B5447"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
        d: "M55.9132 15.4286L51.1428 21.8827V24.8572H66.8571V22.1633L63.7704 18.5153L61.2449 21.3214L55.9132 15.4286Z",
        fill: "#6B5447"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
        d: "M65.2857 13.4643C65.2857 14.5491 64.4063 15.4286 63.3215 15.4286C62.2366 15.4286 61.3572 14.5491 61.3572 13.4643C61.3572 12.3794 62.2366 11.5 63.3215 11.5C64.4063 11.5 65.2857 12.3794 65.2857 13.4643Z",
        fill: "#6B5447"
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M70 46.8571L70 50L48 50L48 46.8571L70 46.8571Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M70 46.8571L70 50L48 50L48 46.8571L70 46.8571Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M70 46.8571L70 50L48 50L48 46.8571L70 46.8571Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M70 40.5714L70 43.7143L48 43.7143L48 40.5714L70 40.5714Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M70 40.5714L70 43.7143L48 43.7143L48 40.5714L70 40.5714Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M70 40.5714L70 43.7143L48 43.7143L48 40.5714L70 40.5714Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M70 34.2857L70 37.4286L48 37.4286L48 34.2857L70 34.2857Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M70 34.2857L70 37.4286L48 37.4286L48 34.2857L70 34.2857Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M70 34.2857L70 37.4286L48 37.4286L48 34.2857L70 34.2857Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M59 53.1429L59 56.2857L48 56.2857L48 53.1429L59 53.1429Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M59 53.1429L59 56.2857L48 56.2857L48 53.1429L59 53.1429Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M59 53.1429L59 56.2857L48 56.2857L48 53.1429L59 53.1429Z",
      fill: "#6B5447"
    })]
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("defs", {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("clipPath", {
      id: "clip0_1415_47",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
        width: "64",
        height: "64",
        fill: "white"
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("clipPath", {
      id: "clip1_1415_47",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
        width: "22",
        height: "22",
        fill: "white",
        transform: "translate(0 6)"
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("clipPath", {
      id: "clip2_1415_47",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
        width: "22",
        height: "22",
        fill: "white",
        transform: "translate(24 6)"
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("clipPath", {
      id: "clip3_1415_47",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
        width: "22",
        height: "22",
        fill: "white",
        transform: "translate(48 6)"
      })
    })]
  })]
});
icons.categoryTeaser = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "64",
  viewBox: "0 0 64 64",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M26 26H38V38H26V26Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M52 26H64V38H52V26Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M0 26H12V38H0V26Z",
    fill: "#6B5447"
  })]
});
icons.postTeaser = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "69",
  viewBox: "0 0 64 69",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
    x: "0.5",
    y: "5.5",
    width: "63",
    height: "63",
    stroke: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M41 51L41 69L23 69L23 51L41 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M41 51L41 69L23 69L23 51L41 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M41 51L41 69L23 69L23 51L41 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M41 28L41 46L23 46L23 28L41 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M41 28L41 46L23 46L23 28L41 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M41 28L41 46L23 46L23 28L41 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 51L18 69L-8.39259e-07 69L0 51L18 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 51L18 69L-8.39259e-07 69L0 51L18 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 51L18 69L-8.39259e-07 69L0 51L18 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 28L64 46L46 46L46 28L64 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 28L64 46L46 46L46 28L64 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 28L64 46L46 46L46 28L64 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 28L64 46L63 46L63 28L64 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 28L64 46L63 46L63 28L64 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 28L64 46L63 46L63 28L64 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 51L64 69L46 69L46 51L64 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 51L64 69L46 69L46 51L64 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 51L64 69L46 69L46 51L64 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 51L64 69L63 69L63 51L64 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 51L64 69L63 69L63 51L64 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 51L64 69L63 69L63 51L64 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 28L18 46L-8.39259e-07 46L0 28L18 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 28L18 46L-8.39259e-07 46L0 28L18 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 28L18 46L-8.39259e-07 46L0 28L18 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 51L64 69L46 69L46 51L64 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 51L64 69L46 69L46 51L64 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 51L64 69L46 69L46 51L64 51Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 28L18 46L-8.39259e-07 46L0 28L18 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 28L18 46L-8.39259e-07 46L0 28L18 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 28L18 46L-8.39259e-07 46L0 28L18 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 28L18 46L17 46L17 28L18 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 28L18 46L17 46L17 28L18 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 28L18 46L17 46L17 28L18 28Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M41 5L41 23L23 23L23 5L41 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M41 5L41 23L23 23L23 5L41 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M41 5L41 23L23 23L23 5L41 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 5L18 23L-8.39259e-07 23L0 5L18 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 5L18 23L-8.39259e-07 23L0 5L18 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18 5L18 23L-8.39259e-07 23L0 5L18 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 5L64 23L46 23L46 5L64 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 5L64 23L46 23L46 5L64 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 5L64 23L46 23L46 5L64 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 5L64 23L63 23L63 5L64 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 5L64 23L63 23L63 5L64 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 5L64 23L63 23L63 5L64 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 5L64 23L46 23L46 5L64 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 5L64 23L46 23L46 5L64 5Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 5L64 23L46 23L46 5L64 5Z",
    fill: "#6B5447"
  })]
});
icons.videoTeaser = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "64",
  viewBox: "0 0 64 64",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    clipPath: "url(#clip0_738_1269)",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M64 64C66.0669 64 64 66.8187 64 64H7.33137e-06C7.33137e-06 66.8187 -2.06695 64 7.33137e-06 64V1.00136e-05C-2.06695 1.00136e-05 7.33137e-06 -2.81869 7.33137e-06 1.00136e-05H64C64 -2.81869 66.0669 1.00136e-05 64 1.00136e-05V64ZM44.4691 29.1429L22.6513 16.9172C21.9525 16.5264 21.1568 16.6349 20.5292 17.2083C19.9018 17.7817 19.525 18.7441 19.525 19.7741V44.2255C19.525 45.2555 19.9015 46.2179 20.5292 46.7913C20.9077 47.1371 21.3476 47.314 21.7903 47.314C22.0814 47.314 22.3739 47.2375 22.6513 47.0824L44.4691 34.8567C45.3186 34.3807 45.8731 33.2521 45.8731 31.9998C45.8731 30.7475 45.3186 29.6193 44.4691 29.1429ZM24.0554 39.6173V24.3823L37.649 31.9998L24.0554 39.6173Z",
      fill: "#6B5447"
    })
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("defs", {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("clipPath", {
      id: "clip0_738_1269",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
        width: "64",
        height: "64",
        fill: "white"
      })
    })
  })]
});
icons.video = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64px",
  height: "64px",
  viewBox: "0 0 16 16",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    id: "SVGRepo_bgCarrier",
    strokeWidth: "0"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    id: "SVGRepo_tracerCarrier",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    id: "SVGRepo_iconCarrier",
    children: [" ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M16 2H0V14H16V2ZM6.5 5V11H7.5L11 8L7.5 5H6.5Z",
      fill: "#000000"
    }), " "]
  })]
});
icons.serviceTeaser = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "64",
  viewBox: "0 0 64 64",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M26 26H38V38H26V26Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M52 26H64V38H52V26Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M0 26H12V38H0V26Z",
    fill: "#6B5447"
  })]
});
icons.cta = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64px",
  height: "64px",
  viewBox: "0 0 17 17",
  version: "1.1",
  xmlns: "http://www.w3.org/2000/svg",
  fill: "#000000",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    id: "SVGRepo_bgCarrier",
    strokeWidth: "0"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    id: "SVGRepo_tracerCarrier",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    id: "SVGRepo_iconCarrier",
    children: [" ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M15 7h-7v-1h7v1zM8.007 9h5v-1h-5v1zM17 3v10h-17v-10h17zM16 4h-15v8h15v-8zM7 6h-5v2h5v-2z",
      fill: "#000000"
    }), " "]
  })]
});
icons.testimonial = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  fill: "#000000",
  version: "1.1",
  id: "Capa_1",
  xmlns: "http://www.w3.org/2000/svg",
  width: "64px",
  height: "64px",
  viewBox: "0 0 478.248 478.248",
  xmlSpace: "preserve",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    id: "SVGRepo_bgCarrier",
    strokeWidth: "0"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    id: "SVGRepo_tracerCarrier",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    id: "SVGRepo_iconCarrier",
    children: [" ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
      children: [" ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
        children: [" ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
          children: [" ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
            d: "M456.02,44.821H264.83c-12.26,0-22.232,9.972-22.232,22.229v98.652c0,12.258,9.974,22.23,22.232,22.23h16.787v39.161 c0,2.707,1.58,5.165,4.043,6.292c0.92,0.42,1.901,0.627,2.875,0.627c1.631,0,3.244-0.576,4.523-1.685l51.383-44.396h111.576 c12.26,0,22.23-9.973,22.23-22.23V67.05C478.25,54.792,468.277,44.821,456.02,44.821z M319.922,112.252l-10.209,9.953 l2.41,14.054c0.174,1.015-0.242,2.038-1.076,2.643c-0.469,0.342-1.027,0.516-1.588,0.516c-0.428,0-0.861-0.103-1.256-0.31 l-12.621-6.635l-12.619,6.635c-0.912,0.478-2.016,0.398-2.848-0.206s-1.248-1.628-1.074-2.643l2.41-14.054l-10.211-9.953 c-0.734-0.718-1.002-1.792-0.685-2.769c0.317-0.978,1.164-1.691,2.183-1.839l14.11-2.05l6.31-12.786 c0.457-0.923,1.396-1.507,2.424-1.507s1.969,0.584,2.422,1.507l6.312,12.786l14.107,2.05c1.02,0.148,1.863,0.861,2.184,1.839 C320.924,110.46,320.658,111.535,319.922,112.252z M384.766,112.252l-10.211,9.953l2.412,14.054 c0.172,1.015-0.244,2.038-1.076,2.643c-0.469,0.342-1.025,0.516-1.588,0.516c-0.43,0-0.859-0.103-1.26-0.31l-12.619-6.635 l-12.619,6.635c-0.912,0.478-2.014,0.398-2.846-0.206c-0.834-0.604-1.25-1.628-1.076-2.643l2.41-14.054l-10.209-9.953 c-0.734-0.718-1.002-1.792-0.684-2.769c0.316-0.978,1.16-1.691,2.182-1.839l14.109-2.05l6.311-12.786 c0.455-0.923,1.396-1.507,2.422-1.507c1.029,0,1.967,0.584,2.422,1.507l6.312,12.786l14.109,2.05 c1.021,0.148,1.863,0.861,2.182,1.839C385.768,110.46,385.5,111.535,384.766,112.252z M449.607,112.252l-10.211,9.953 l2.408,14.054c0.176,1.015-0.238,2.038-1.072,2.643c-0.471,0.342-1.027,0.516-1.59,0.516c-0.43,0-0.859-0.103-1.258-0.31 l-12.621-6.635l-12.621,6.635c-0.908,0.478-2.012,0.398-2.844-0.206c-0.834-0.604-1.248-1.628-1.076-2.643l2.412-14.054 l-10.211-9.953c-0.734-0.718-1-1.792-0.684-2.769c0.316-0.978,1.164-1.691,2.182-1.839l14.111-2.05l6.311-12.786 c0.453-0.923,1.395-1.507,2.42-1.507c1.027,0,1.971,0.584,2.426,1.507L434,105.594l14.109,2.05 c1.018,0.148,1.861,0.861,2.182,1.839C450.609,110.46,450.344,111.535,449.607,112.252z"
          }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
            d: "M152.844,112.924c-46.76,0-72.639,24.231-72.166,70.921c0.686,63.947,27.859,102.74,72.166,102.063 c0,0,72.131,2.924,72.131-102.063C224.975,137.155,200.605,112.924,152.844,112.924z"
          }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
            d: "M280.428,334.444l-72.074-28.736l-16.877-14.223c-4.457-3.766-11.041-3.488-15.178,0.621l-23.463,23.336l-23.533-23.342 c-4.137-4.104-10.713-4.369-15.164-0.615l-16.881,14.223l-72.074,28.739C1.975,343.69,1.995,425.884,0,433.427h305.646 C303.656,425.9,303.646,343.679,280.428,334.444z"
          }), " "]
        }), " "]
      }), " "]
    }), " "]
  })]
});
icons.products = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64px",
  height: "64px",
  viewBox: "0 0 24 24",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    id: "SVGRepo_bgCarrier",
    strokeWidth: "0"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    id: "SVGRepo_tracerCarrier",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    id: "SVGRepo_iconCarrier",
    children: [" ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M13.5 2.75H20.5V1.25H13.5V2.75ZM21.25 3.5V7.5H22.75V3.5H21.25ZM20.5 8.25H13.5V9.75H20.5V8.25ZM12.75 7.5V3.5H11.25V7.5H12.75ZM13.5 8.25C13.0858 8.25 12.75 7.91421 12.75 7.5H11.25C11.25 8.74264 12.2574 9.75 13.5 9.75V8.25ZM21.25 7.5C21.25 7.91421 20.9142 8.25 20.5 8.25V9.75C21.7426 9.75 22.75 8.74264 22.75 7.5H21.25ZM20.5 2.75C20.9142 2.75 21.25 3.08579 21.25 3.5H22.75C22.75 2.25736 21.7426 1.25 20.5 1.25V2.75ZM13.5 1.25C12.2574 1.25 11.25 2.25736 11.25 3.5H12.75C12.75 3.08579 13.0858 2.75 13.5 2.75V1.25Z",
      fill: "#000000"
    }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M2 13.25C1.58579 13.25 1.25 13.5858 1.25 14C1.25 14.4142 1.58579 14.75 2 14.75V13.25ZM22 14.75C22.4142 14.75 22.75 14.4142 22.75 14C22.75 13.5858 22.4142 13.25 22 13.25V14.75ZM2 14.75H22V13.25H2V14.75Z",
      fill: "#000000"
    }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M2 17.25C1.58579 17.25 1.25 17.5858 1.25 18C1.25 18.4142 1.58579 18.75 2 18.75V17.25ZM22 18.75C22.4142 18.75 22.75 18.4142 22.75 18C22.75 17.5858 22.4142 17.25 22 17.25V18.75ZM2 18.75H22V17.25H2V18.75Z",
      fill: "#000000"
    }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M2 21.25C1.58579 21.25 1.25 21.5858 1.25 22C1.25 22.4142 1.58579 22.75 2 22.75V21.25ZM14 22.75C14.4142 22.75 14.75 22.4142 14.75 22C14.75 21.5858 14.4142 21.25 14 21.25V22.75ZM2 22.75H14V21.25H2V22.75Z",
      fill: "#000000"
    }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M9 6.25C9.41421 6.25 9.75 5.91421 9.75 5.5C9.75 5.08579 9.41421 4.75 9 4.75V6.25ZM2 4.75C1.58579 4.75 1.25 5.08579 1.25 5.5C1.25 5.91421 1.58579 6.25 2 6.25V4.75ZM9 4.75H2V6.25H9V4.75Z",
      fill: "#000000"
    }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M6.56944 1.51191C6.29988 1.19741 5.8264 1.16099 5.51191 1.43056C5.19741 1.70012 5.16099 2.1736 5.43056 2.48809L6.56944 1.51191ZM9 5.5L9.56944 5.98809C9.81019 5.70723 9.81019 5.29277 9.56944 5.01191L9 5.5ZM5.43056 8.51191C5.16099 8.8264 5.19741 9.29988 5.51191 9.56944C5.8264 9.83901 6.29988 9.80259 6.56944 9.48809L5.43056 8.51191ZM5.43056 2.48809L8.43056 5.98809L9.56944 5.01191L6.56944 1.51191L5.43056 2.48809ZM8.43056 5.01191L5.43056 8.51191L6.56944 9.48809L9.56944 5.98809L8.43056 5.01191Z",
      fill: "#000000"
    }), " "]
  })]
});
icons.features = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64px",
  height: "64px",
  viewBox: "0 0 16 16",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    id: "SVGRepo_bgCarrier",
    strokeWidth: "0"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    id: "SVGRepo_tracerCarrier",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    id: "SVGRepo_iconCarrier",
    children: [" ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M15 1H1V3H15V1Z",
      fill: "#000000"
    }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M15 5H1V7H15V5Z",
      fill: "#000000"
    }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M7 9H1V11H7V9Z",
      fill: "#000000"
    }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M1 13H7V15H1V13Z",
      fill: "#000000"
    }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M11 9V11H9V13H11V15H13V13H15V11H13V9H11Z",
      fill: "#000000"
    }), " "]
  })]
});
icons.midPageCta = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "28",
  viewBox: "0 0 64 28",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    clipPath: "url(#clip0_1329_27)",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M60 4H40V24H60V4ZM36 0V28H64V0H36Z",
      fill: "#000000ff"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46.0714 12L40 20.2143V24H60V20.5714L56.0714 15.9286L52.8571 19.5L46.0714 12Z",
      fill: "#000000ff"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M58 9.5C58 10.8807 56.8807 12 55.5 12C54.1193 12 53 10.8807 53 9.5C53 8.11929 54.1193 7 55.5 7C56.8807 7 58 8.11929 58 9.5Z",
      fill: "#6B5447"
    })]
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 12L28 16L-1.63189e-07 16L0 12L28 12Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 12L28 16L-1.63189e-07 16L0 12L28 12Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 12L28 16L-1.63189e-07 16L0 12L28 12Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 4L28 8L-1.63189e-07 8L0 4L28 4Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 4L28 8L-1.63189e-07 8L0 4L28 4Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 4L28 8L-1.63189e-07 8L0 4L28 4Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M14 20L14 24L-1.63189e-07 24L0 20L14 20Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M14 20L14 24L-1.63189e-07 24L0 20L14 20Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M14 20L14 24L-1.63189e-07 24L0 20L14 20Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("defs", {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("clipPath", {
      id: "clip0_1329_27",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
        width: "28",
        height: "28",
        fill: "white",
        transform: "translate(36)"
      })
    })
  })]
});
icons.newsLetter = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "64",
  viewBox: "0 0 64 64",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M61.64 17L61.64 27.1363L3 27.1363L3 17L61.64 17Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M61.64 17L61.64 27.1363L3 27.1363L3 17L61.64 17Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M61.64 17L61.64 27.1363L3 27.1363L3 17L61.64 17Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M49.1983 42.475L49.1983 46.9207L15.4417 46.9207L15.4417 42.475L49.1983 42.475Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M49.1983 42.475L49.1983 46.9207L15.4417 46.9207L15.4417 42.475L49.1983 42.475Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M49.1983 42.475L49.1983 46.9207L15.4417 46.9207L15.4417 42.475L49.1983 42.475Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M49.1983 34.6949L49.1983 39.1407L15.4417 39.1407L15.4417 34.6949L49.1983 34.6949Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M49.1983 34.6949L49.1983 39.1407L15.4417 39.1407L15.4417 34.6949L49.1983 34.6949Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M49.1983 34.6949L49.1983 39.1407L15.4417 39.1407L15.4417 34.6949L49.1983 34.6949Z",
    fill: "#6b5447"
  })]
});
icons.sectionHead = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "64",
  viewBox: "0 0 64 64",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M61.64 17L61.64 27.1363L3 27.1363L3 17L61.64 17Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M61.64 17L61.64 27.1363L3 27.1363L3 17L61.64 17Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M61.64 17L61.64 27.1363L3 27.1363L3 17L61.64 17Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M49.1983 42.475L49.1983 46.9207L15.4417 46.9207L15.4417 42.475L49.1983 42.475Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M49.1983 42.475L49.1983 46.9207L15.4417 46.9207L15.4417 42.475L49.1983 42.475Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M49.1983 42.475L49.1983 46.9207L15.4417 46.9207L15.4417 42.475L49.1983 42.475Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M49.1983 34.6949L49.1983 39.1407L15.4417 39.1407L15.4417 34.6949L49.1983 34.6949Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M49.1983 34.6949L49.1983 39.1407L15.4417 39.1407L15.4417 34.6949L49.1983 34.6949Z",
    fill: "#6b5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M49.1983 34.6949L49.1983 39.1407L15.4417 39.1407L15.4417 34.6949L49.1983 34.6949Z",
    fill: "#6b5447"
  })]
});
icons.themeImage = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "64",
  viewBox: "0 0 64 64",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    clipPath: "url(#clip0_738_742)",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M60 4H4V60H60V4ZM0 0V64H64V0H0Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M21 18L4 41V60H60V42L49 29L40 39L21 18Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M50 16C50 19.866 46.866 23 43 23C39.134 23 36 19.866 36 16C36 12.134 39.134 9 43 9C46.866 9 50 12.134 50 16Z",
      fill: "#6B5447"
    })]
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("defs", {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("clipPath", {
      id: "clip0_738_742",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
        width: "64",
        height: "64",
        fill: "white"
      })
    })
  })]
});
icons.textImageColumn = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "64",
  viewBox: "0 0 64 64",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    clipPath: "url(#clip0_738_1087)",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M24 4H4V24H24V4ZM0 0V28H28V0H0Z",
      fill: "#000000ff"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M10.0714 12L4 20.2143V24H24V20.5714L20.0714 15.9286L16.8571 19.5L10.0714 12Z",
      fill: "#000000ff"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M22 9.5C22 10.8807 20.8807 12 19.5 12C18.1193 12 17 10.8807 17 9.5C17 8.11929 18.1193 7 19.5 7C20.8807 7 22 8.11929 22 9.5Z",
      fill: "#6B5447"
    })]
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 52L28 56L-1.63189e-07 56L0 52L28 52Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 52L28 56L-1.63189e-07 56L0 52L28 52Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 52L28 56L-1.63189e-07 56L0 52L28 52Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 44L28 48L-1.63189e-07 48L0 44L28 44Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 44L28 48L-1.63189e-07 48L0 44L28 44Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 44L28 48L-1.63189e-07 48L0 44L28 44Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 36L28 40L-1.63189e-07 40L0 36L28 36Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 36L28 40L-1.63189e-07 40L0 36L28 36Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M28 36L28 40L-1.63189e-07 40L0 36L28 36Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M14 60L14 64L-1.63189e-07 64L0 60L14 60Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M14 60L14 64L-1.63189e-07 64L0 60L14 60Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M14 60L14 64L-1.63189e-07 64L0 60L14 60Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    clipPath: "url(#clip1_738_1087)",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M60 4H40V24H60V4ZM36 0V28H64V0H36Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46.0714 12L40 20.2143V24H60V20.5714L56.0714 15.9286L52.8571 19.5L46.0714 12Z",
      fill: "#6B5447"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M56 9.5C56 10.8807 54.8807 12 53.5 12C52.1193 12 51 10.8807 51 9.5C51 8.11929 52.1193 7 53.5 7C54.8807 7 56 8.11929 56 9.5Z",
      fill: "#6B5447"
    })]
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 52L64 56L36 56L36 52L64 52Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 52L64 56L36 56L36 52L64 52Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 52L64 56L36 56L36 52L64 52Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 44L64 48L36 48L36 44L64 44Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 44L64 48L36 48L36 44L64 44Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 44L64 48L36 48L36 44L64 44Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 36L64 40L36 40L36 36L64 36Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 36L64 40L36 40L36 36L64 36Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 36L64 40L36 40L36 36L64 36Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M50 60L50 64L36 64L36 60L50 60Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M50 60L50 64L36 64L36 60L50 60Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M50 60L50 64L36 64L36 60L50 60Z",
    fill: "#6B5447"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("defs", {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("clipPath", {
      id: "clip0_738_1087",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
        width: "28",
        height: "28",
        fill: "white"
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("clipPath", {
      id: "clip1_738_1087",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
        width: "28",
        height: "28",
        fill: "white",
        transform: "translate(36)"
      })
    })]
  })]
});
icons.socials = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", {
  id: "fi_4187236",
  enableBackground: "new 0 0 517.395 517.395",
  height: "512",
  viewBox: "0 0 517.395 517.395",
  width: "512",
  xmlns: "http://www.w3.org/2000/svg",
  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "m397.204 156.407h12.079v47.674c0 4.143 3.357 7.5 7.5 7.5s7.5-3.357 7.5-7.5v-47.674h12.078c4.143 0 7.5-3.357 7.5-7.5s-3.357-7.5-7.5-7.5h-12.078v-21.79c0-4.188 3.406-7.594 7.594-7.594h17.772c4.143 0 7.5-3.357 7.5-7.5s-3.357-7.5-7.5-7.5h-17.772c-12.458 0-22.594 10.136-22.594 22.594v21.79h-12.079c-4.143 0-7.5 3.357-7.5 7.5s3.358 7.5 7.5 7.5zm-135.809-112.95c4.142 0 7.5-3.358 7.5-7.5s-3.358-7.5-7.5-7.5-7.5 3.358-7.5 7.5 3.357 7.5 7.5 7.5zm-162.033 130.314c12.406 0 22.5-10.094 22.5-22.5s-10.094-22.5-22.5-22.5-22.5 10.094-22.5 22.5 10.094 22.5 22.5 22.5zm0-30c4.136 0 7.5 3.364 7.5 7.5s-3.364 7.5-7.5 7.5-7.5-3.364-7.5-7.5 3.365-7.5 7.5-7.5zm30 60c12.406 0 22.5-10.094 22.5-22.5v-60c0-12.406-10.094-22.5-22.5-22.5h-60c-12.406 0-22.5 10.094-22.5 22.5v60c0 12.406 10.094 22.5 22.5 22.5zm-67.5-22.5v-60c0-4.136 3.364-7.5 7.5-7.5h60c4.136 0 7.5 3.364 7.5 7.5v60c0 4.136-3.364 7.5-7.5 7.5h-60c-4.135 0-7.5-3.365-7.5-7.5zm82.954 133.598c-3.641-2.739-8.46-3.199-12.579-1.204-1.01.489-2.071.859-3.154 1.102-1.322.295-2.668.405-4.024.322-4.42-4.062-10.044-6.493-16.121-6.916-7.083-.501-13.947 1.802-19.311 6.466-4.948 4.304-8.09 10.218-8.923 16.626-8.727-1.407-16.722-5.824-22.618-12.646-2.419-2.801-6.167-4.053-9.772-3.272-3.587.776-6.458 3.448-7.493 6.97-2.523 8.571-7.848 34.828 14.316 52.334-4.23 1.29-9.054 1.193-11.521 5.477-2.224 3.862-1.035 8.411-.128 10.78 1.772 4.626 6.396 7.956 13.741 9.897 4.009 1.06 9.249 1.745 15.154 1.745 13.696-.001 30.955-3.688 44.632-14.936 13.631-11.211 19.205-26.495 21.453-38.092 3.499-3.988 6.271-8.489 8.254-13.411 1.24-3.08 2.153-6.304 2.716-9.585.765-4.472-1.005-8.939-4.622-11.657zm-18.729 25.959c-1.062 1.097-1.766 2.491-2.014 3.998-1.531 9.271-5.651 22.21-16.586 31.203-13.221 10.872-31.83 12.399-42.532 11.021 3.571-1.482 6.994-3.322 10.18-5.485 2.253-1.529 3.501-4.159 3.259-6.872-.242-2.712-1.936-5.08-4.425-6.187-18.675-8.301-21.617-22.431-20.457-33.514 9.708 7.864 21.929 12.097 34.665 11.739 4.065-.105 7.306-3.431 7.306-7.497v-4.265c0-.033 0-.067-.001-.101-.046-3.42 1.408-6.669 3.989-8.913 2.339-2.035 5.33-3.033 8.424-2.821 3.093.216 5.917 1.623 7.951 3.962 1.091 1.254 2.565 2.109 4.195 2.434 4.439.883 8.932.769 13.27-.356-1.531 4.36-3.987 8.313-7.224 11.654zm297.34-79.462c-.178 0-.354.007-.532.008v-16.142c.178.001.354.007.532.007 51.814 0 93.968-42.153 93.968-93.968 0-52.025-42.494-94.256-94.5-93.961v-7.112c0-26.191-21.309-47.5-47.5-47.5h-228c-26.191 0-47.5 21.309-47.5 47.5v7.112c-18.374-.107-36.202 5.094-51.558 15.041-3.477 2.252-4.47 6.896-2.218 10.372 2.253 3.477 6.896 4.47 10.372 2.218 12.763-8.268 27.588-12.638 42.871-12.638 43.543 0 78.968 35.425 78.968 78.968s-35.425 78.968-78.968 78.968-78.968-35.425-78.968-78.968c0-15.786 4.641-31.02 13.419-44.054 2.313-3.436 1.404-8.096-2.031-10.41-3.436-2.312-8.096-1.404-10.41 2.031-10.452 15.52-15.978 33.65-15.978 52.433 0 51.814 42.153 93.968 93.968 93.968.178 0 .354-.006.532-.007v16.327c-1.961-.123-3.936-.192-5.927-.192-51.814-.001-93.967 42.153-93.967 93.967s42.153 93.969 93.968 93.969c1.991 0 3.966-.07 5.927-.192v18.087c0 26.191 21.309 47.5 47.5 47.5h228c26.191 0 47.5-21.309 47.5-47.5v-17.901c.178.001.354.007.532.007 51.814 0 93.968-42.154 93.968-93.969s-42.154-93.969-93.968-93.969zm0-189.063c43.543 0 78.968 35.425 78.968 78.968s-35.425 78.968-78.968 78.968-78.968-35.425-78.968-78.968 35.425-78.968 78.968-78.968zm-15.532 171.644v18.693c-5.128.846-10.141 2.111-15 3.77v-26.268c4.834 1.666 9.847 2.945 15 3.805zm-278-188.75v7.201c-4.835-1.666-9.847-2.944-15-3.805v-8.396c0-17.921 14.579-32.5 32.5-32.5h228c17.921 0 32.5 14.579 32.5 32.5v8.396c-5.153.861-10.165 2.139-15 3.805v-7.201c0-12.406-10.094-22.5-22.5-22.5h-27.55c-8.547 0-15.5 6.953-15.5 15.5 0 3.319-2.701 6.02-6.021 6.02h-119.859c-3.319 0-6.021-2.7-6.021-6.02 0-4.145-1.611-8.038-4.557-10.983-2.935-2.912-6.82-4.517-10.943-4.517h-27.55c-12.406 0-22.499 10.094-22.499 22.5zm-15 188.75c5.153-.861 10.165-2.139 15-3.805v28.368c-4.813-1.999-9.825-3.611-15-4.792zm-20.927 190.356c-43.543 0-78.968-35.425-78.968-78.969 0-43.543 35.425-78.968 78.968-78.968s78.968 35.425 78.968 78.968c0 46.025-36.331 78.969-78.968 78.969zm313.927 32.894c0 17.921-14.579 32.5-32.5 32.5h-228c-17.921 0-32.5-14.579-32.5-32.5v-20.246c5.175-1.181 10.187-2.794 15-4.793v20.039c0 12.406 10.094 22.5 22.5 22.5h218c12.406 0 22.5-10.094 22.5-22.5v-17.99c4.835 1.666 9.847 2.944 15 3.805zm15.532-32.894c-43.543 0-78.968-35.425-78.968-78.969 0-6.767.855-13.484 2.544-19.965 1.044-4.009-1.359-8.104-5.367-9.148-4.009-1.046-8.104 1.359-9.148 5.367-2.01 7.715-3.028 15.704-3.028 23.746 0 35.305 19.574 66.119 48.436 82.175v24.688c0 4.136-3.364 7.5-7.5 7.5h-218c-4.136 0-7.5-3.364-7.5-7.5v-27.927c25.88-16.755 43.041-45.878 43.041-78.936s-17.161-62.181-43.041-78.936v-42.954c28.862-16.056 48.436-46.87 48.436-82.174s-19.574-66.118-48.436-82.174v-13.899c0-4.136 3.364-7.5 7.5-7.5h27.55c.141 0 .268.055.356.144.129.128.144.265.144.356 0 11.59 9.43 21.02 21.021 21.02h119.859c11.591 0 21.021-9.43 21.021-21.02 0-.275.225-.5.5-.5h27.55c4.136 0 7.5 3.364 7.5 7.5v13.899c-28.862 16.056-48.436 46.87-48.436 82.174 0 35.326 19.598 66.156 48.489 82.204-.032.283-.053.57-.053.862v38.729c-11.06 6.132-20.911 14.542-28.927 24.939-2.529 3.28-1.92 7.989 1.36 10.519 3.282 2.53 7.989 1.922 10.519-1.36 15.089-19.58 37.575-30.797 62.58-30.797 43.543 0 78.968 35.425 78.968 78.968-.002 43.544-35.427 78.969-78.97 78.969zm-134.548-178.086c-3.541-2.147-8.153-1.021-10.304 2.519-1.39 2.289-3.349 4.25-5.598 5.705-2.167 1.402-4.989 1.442-7.193.104l-11.225-6.814c-2.238-1.359-3.462-3.968-3.209-6.613.25-2.61 1.102-5.175 2.463-7.416 2.15-3.541 1.023-8.153-2.517-10.304-3.539-2.15-8.153-1.024-10.304 2.517-2.528 4.163-4.11 8.926-4.577 13.802l-.014.151c-.792 8.258 3.279 16.376 10.371 20.685l11.225 6.814c3.452 2.097 7.375 3.142 11.296 3.142 4.134 0 8.266-1.162 11.838-3.477 4.139-2.682 7.708-6.295 10.266-10.51 2.15-3.543 1.022-8.155-2.518-10.305zm174.013 91.075-52.588-30.377c-6.802-4.004-15.666 1.201-15.607 9.01v60.755c-.07 7.791 8.859 12.99 15.606 9.01l52.588-30.376c6.8-3.854 6.775-14.186.001-18.022zm-53.196 31.426v-44.831l38.806 22.416zm-150.122-187.936c-34.855.914-63.84 28.876-65.986 63.658-.548 8.858.603 17.583 3.418 25.937l-7.986 22.719c-1.481 4.212-.439 8.789 2.717 11.946 3.156 3.156 7.734 4.197 11.945 2.717l15.839-5.567c12.427 9.742 27.965 14.847 43.755 14.419 36.303-.984 65.937-31.347 66.058-67.682.062-18.53-7.202-35.868-20.454-48.82-13.249-12.95-30.769-19.824-49.306-19.327zm3.295 120.834c-12.385.315-24.521-3.684-34.206-11.318-2.646-2.087-5.832-3.172-9.058-3.172-1.609 0-3.229.27-4.795.821l-9.221 3.241 5.627-16.007c1.072-3.049 1.095-6.395.062-9.421-2.236-6.56-3.151-13.422-2.721-20.396 1.673-27.095 24.254-48.876 51.408-49.589 14.457-.392 28.104 4.97 38.428 15.06 10.326 10.093 15.986 23.604 15.938 38.042-.093 28.314-23.18 51.972-51.462 52.739z"
    })
  })
});
icons.serviceteaser = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "64",
  height: "45",
  viewBox: "0 0 64 45",
  fill: "none",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    clipPath: "url(#clip0_1355_804)",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M24 6.42857H4V38.5714H24V6.42857ZM0 0V45H28V0H0Z",
      fill: "black"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M10.0714 19.2857L4 32.4872V38.5714H24V33.0612L20.0714 25.5995L16.8571 31.3393L10.0714 19.2857Z",
      fill: "black"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M22 15.2679C22 17.4869 20.8807 19.2857 19.5 19.2857C18.1193 19.2857 17 17.4869 17 15.2679C17 13.0489 18.1193 11.25 19.5 11.25C20.8807 11.25 22 13.0489 22 15.2679Z",
      fill: "black"
    })]
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
    clipPath: "url(#clip1_1355_804)",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M60 6.42857H40V38.5714H60V6.42857ZM36 0V45H64V0H36Z",
      fill: "black"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M46.0714 19.2857L40 32.4872V38.5714H60V33.0612L56.0714 25.5995L52.8571 31.3393L46.0714 19.2857Z",
      fill: "black"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
      d: "M58 15.2679C58 17.4869 56.8807 19.2857 55.5 19.2857C54.1193 19.2857 53 17.4869 53 15.2679C53 13.0489 54.1193 11.25 55.5 11.25C56.8807 11.25 58 13.0489 58 15.2679Z",
      fill: "black"
    })]
  })]
});
icons.postgrid = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  width: "64",
  height: "64",
  viewBox: "0 0 64 64",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
  children: [" ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
    width: "64",
    height: "64",
    transform: "matrix(1 0 0 -1 0 64)",
    fill: "white"
  }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18.1272 23V38H-1.90735e-06V23L18.1272 23Z",
    fill: "#6B5447"
  }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 23V38H45.8728V23L64 23Z",
    fill: "#6B5447"
  }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M41.4335 23V38H23.3064V23L41.4335 23Z",
    fill: "#6B5447"
  }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18.1272 48.7283V63.7283H3.8147e-06V48.7283L18.1272 48.7283Z",
    fill: "#6B5447"
  }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 48.7283V63.7283H45.8728V48.7283L64 48.7283Z",
    fill: "#6B5447"
  }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M41.4335 48.7283V63.7283H23.3063V48.7283L41.4335 48.7283Z",
    fill: "#6B5447"
  }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M16 0V14L0 14V0L16 0Z",
    fill: "#6B5447"
  }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M64 0V14L48 14V0L64 0Z",
    fill: "#6B5447"
  }), " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M40 0V14L24 14V0L40 0Z",
    fill: "#6B5447"
  }), " "]
});
icons.item = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "64",
  height: "64",
  viewBox: "0 0 64 64",
  fill: "none",
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M9.33325 20C11.5424 20 13.3333 18.2091 13.3333 16C13.3333 13.7909 11.5424 12 9.33325 12C7.12411 12 5.33325 13.7909 5.33325 16C5.33325 18.2091 7.12411 20 9.33325 20Z",
    fill: "black"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M21.3334 13.3333C19.8607 13.3333 18.6667 14.5273 18.6667 16C18.6667 17.4728 19.8607 18.6667 21.3334 18.6667H56.0001C57.4729 18.6667 58.6667 17.4728 58.6667 16C58.6667 14.5273 57.4729 13.3333 56.0001 13.3333H21.3334Z",
    fill: "black"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M21.3334 29.3333C19.8607 29.3333 18.6667 30.5272 18.6667 32C18.6667 33.4728 19.8607 34.6667 21.3334 34.6667H56.0001C57.4729 34.6667 58.6667 33.4728 58.6667 32C58.6667 30.5272 57.4729 29.3333 56.0001 29.3333H21.3334Z",
    fill: "black"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M18.6667 48C18.6667 46.5272 19.8607 45.3333 21.3334 45.3333H56.0001C57.4729 45.3333 58.6667 46.5272 58.6667 48C58.6667 49.4728 57.4729 50.6667 56.0001 50.6667H21.3334C19.8607 50.6667 18.6667 49.4728 18.6667 48Z",
    fill: "black"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M13.3333 32C13.3333 34.2091 11.5424 36 9.33325 36C7.12411 36 5.33325 34.2091 5.33325 32C5.33325 29.7909 7.12411 28 9.33325 28C11.5424 28 13.3333 29.7909 13.3333 32Z",
    fill: "black"
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", {
    d: "M9.33325 52C11.5424 52 13.3333 50.2091 13.3333 48C13.3333 45.7909 11.5424 44 9.33325 44C7.12411 44 5.33325 45.7909 5.33325 48C5.33325 50.2091 7.12411 52 9.33325 52Z",
    fill: "black"
  })]
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (icons);

/***/ }),

/***/ "./src/block-assets/preview-images/features.webp":
/*!*******************************************************!*\
  !*** ./src/block-assets/preview-images/features.webp ***!
  \*******************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "images/features.411645b3.webp";

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = window["React"];

/***/ }),

/***/ "react/jsx-runtime":
/*!**********************************!*\
  !*** external "ReactJSXRuntime" ***!
  \**********************************/
/***/ ((module) => {

module.exports = window["ReactJSXRuntime"];

/***/ }),

/***/ "@wordpress/block-editor":
/*!*************************************!*\
  !*** external ["wp","blockEditor"] ***!
  \*************************************/
/***/ ((module) => {

module.exports = window["wp"]["blockEditor"];

/***/ }),

/***/ "@wordpress/blocks":
/*!********************************!*\
  !*** external ["wp","blocks"] ***!
  \********************************/
/***/ ((module) => {

module.exports = window["wp"]["blocks"];

/***/ }),

/***/ "@wordpress/components":
/*!************************************!*\
  !*** external ["wp","components"] ***!
  \************************************/
/***/ ((module) => {

module.exports = window["wp"]["components"];

/***/ }),

/***/ "@wordpress/i18n":
/*!******************************!*\
  !*** external ["wp","i18n"] ***!
  \******************************/
/***/ ((module) => {

module.exports = window["wp"]["i18n"];

/***/ }),

/***/ "./src/features/block.json":
/*!*********************************!*\
  !*** ./src/features/block.json ***!
  \*********************************/
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"$schema":"https://raw.githubusercontent.com/WordPress/gutenberg/trunk/schemas/json/block.json","apiVersion":3,"name":"stonestomperpack/features","version":"1.0.0","title":"Stone Stomper - Features","category":"theme-blocks","icon":"align-center","description":"","supports":{"html":false,"align":["wide","full"]},"attributes":{"preview":{"type":"boolean","default":false},"selected":{"type":"string","default":""}},"example":{"attributes":{"preview":true}},"textdomain":"stonestomper_td","editorScript":"file:./block-features.js"}');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript)
/******/ 				scriptUrl = document.currentScript.src;
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) {
/******/ 					var i = scripts.length - 1;
/******/ 					while (i > -1 && (!scriptUrl || !/^http(s?):/.test(scriptUrl))) scriptUrl = scripts[i--].src;
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl + "../";
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
/*!*****************************************!*\
  !*** ./src/features/block-features.jsx ***!
  \*****************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_blocks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/blocks */ "@wordpress/blocks");
/* harmony import */ var _wordpress_blocks__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_blocks__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _block_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./block.json */ "./src/features/block.json");
/* harmony import */ var _block_assets_icons_Icons_jsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../block-assets/icons/Icons.jsx */ "./src/block-assets/icons/Icons.jsx");
/* harmony import */ var _block_assets_preview_images_features_webp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../block-assets/preview-images/features.webp */ "./src/block-assets/preview-images/features.webp");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _block_assets_components_ContainerBlock_jsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../block-assets/components/ContainerBlock.jsx */ "./src/block-assets/components/ContainerBlock.jsx");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);







_block_assets_components_ContainerBlock_jsx__WEBPACK_IMPORTED_MODULE_5__.customAttributes.bgWidth.default = '';
_block_assets_components_ContainerBlock_jsx__WEBPACK_IMPORTED_MODULE_5__.customAttributes.bgDesignType.default = '';
(0,_wordpress_blocks__WEBPACK_IMPORTED_MODULE_0__.registerBlockType)(_block_json__WEBPACK_IMPORTED_MODULE_1__.name, {
  attributes: {
    ..._block_json__WEBPACK_IMPORTED_MODULE_1__.attributes,
    ..._block_assets_components_ContainerBlock_jsx__WEBPACK_IMPORTED_MODULE_5__.customAttributes
  },
  icon: _block_assets_icons_Icons_jsx__WEBPACK_IMPORTED_MODULE_2__["default"].features,
  edit: Edit,
  save: Save
});
function Edit(props) {
  const {
    attributes,
    setAttributes
  } = props;
  const {
    preview,
    className
  } = attributes;
  const myCustomClassName = className ? className : undefined;
  const classes = [myCustomClassName].join(' ');
  const allowedBlocks = ['core/columns', 'core/column', 'core/image', 'core/heading', 'core/group', 'core/button', 'core/spacer'];
  const TEMPLATE = [['core/columns', {
    className: 'stone-stomper-features'
  }, [['core/column', {
    className: 'features-image image-cover',
    style: {
      flexBasis: '66%'
    },
    width: '66%',
    verticalAlignment: 'center'
  }, [['core/image', {
    className: 'size-full'
  }]]], ['core/column', {
    className: 'features-tile',
    style: {
      flexBasis: '32%'
    },
    width: '32%',
    verticalAlignment: 'center'
  }, [['core/image', {
    className: 'size-full'
  }], ['core/group', {
    className: 'features-inner-content'
  }, [['core/heading', {
    placeholder: 'Enter heading…',
    className: 'heading-4',
    level: 2
  }], ['core/paragraph', {
    placeholder: 'Enter your description text here…'
  }]]]]]]]];
  const blockProps = (0,_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__.useBlockProps)();
  const {
    children,
    ...innerBlocksProps
  } = (0,_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__.useInnerBlocksProps)(blockProps, {
    template: TEMPLATE,
    templateLock: false,
    // set 'all' if you want to lock structure
    allowedBlocks
  });

  // Block preview
  if (preview) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)("div", {
      className: "block-preview",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)("img", {
        src: _block_assets_preview_images_features_webp__WEBPACK_IMPORTED_MODULE_3__,
        alt: "Preview",
        style: {
          width: '100%',
          height: '100%',
          objectFit: 'cover'
        }
      })
    });
  }
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)("div", {
    ...blockProps,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(_block_assets_components_ContainerBlock_jsx__WEBPACK_IMPORTED_MODULE_5__["default"], {
      props: props,
      customClassName: classes,
      children: children
    })
  });
}
function Save(props) {
  const {
    attributes
  } = props;
  const {
    className
  } = attributes;
  const myCustomClassName = className ? className : '';
  const classes = [myCustomClassName].join(' ');
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(_block_assets_components_ContainerBlock_jsx__WEBPACK_IMPORTED_MODULE_5__.ContainerBlockContent, {
    props: props,
    customClassName: classes,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__.InnerBlocks.Content, {})
  });
}
/******/ })()
;
//# sourceMappingURL=block-features.js.map